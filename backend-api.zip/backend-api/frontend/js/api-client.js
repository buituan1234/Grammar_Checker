// public/js/api-client.js - API Client for Frontend
class ApiClient {
    constructor() {
        this.baseURL = window.location.origin + '/api';
        this.token = localStorage.getItem('authToken');
    }

    // Set authentication token
    setToken(token) {
        this.token = token;
        if (token) {
            localStorage.setItem('authToken', token);
        } else {
            localStorage.removeItem('authToken');
        }
    }

    // Get authentication token
    getToken() {
        return this.token || localStorage.getItem('authToken');
    }

    // Get headers with authentication
    getHeaders() {
        const headers = {
            'Content-Type': 'application/json',
        };
        
        const token = this.getToken();
        if (token) {
            headers['Authorization'] = `Bearer ${token}`;
        }
        
        return headers;
    }

    // Generic API request method
    async request(endpoint, options = {}) {
        const url = `${this.baseURL}${endpoint}`;
        
        const config = {
            headers: this.getHeaders(),
            ...options
        };

        try {
            console.log('API Request:', { url, config });
            
            const response = await fetch(url, config);
            const data = await response.json();

            console.log('API Response:', { status: response.status, data });

            if (!response.ok) {
                throw new Error(data.error || `HTTP error! status: ${response.status}`);
            }

            return data;
        } catch (error) {
            console.error('API Error:', error);
            throw error;
        }
    }

    // Authentication methods
    async register(userData) {
        return this.request('/auth/register', {
            method: 'POST',
            body: JSON.stringify(userData)
        });
    }

    async login(credentials) {
        const response = await this.request('/auth/login', {
            method: 'POST',
            body: JSON.stringify(credentials)
        });
        
        if (response.success && response.data.token) {
            this.setToken(response.data.token);
        }
        
        return response;
    }

    async logout() {
        try {
            await this.request('/auth/logout', {
                method: 'POST'
            });
        } catch (error) {
            console.error('Logout error:', error);
        } finally {
            this.setToken(null);
            localStorage.removeItem('userData');
        }
    }

    async verifyToken() {
        return this.request('/auth/verify', {
            method: 'GET'
        });
    }

    // Grammar check methods
    async checkGrammar(text, language = 'en-US') {
        return this.request('/grammar/check', {
            method: 'POST',
            body: JSON.stringify({ text, language })
        });
    }

    async getLanguages() {
        return this.request('/grammar/languages', {
            method: 'GET'
        });
    }

    async getUsage() {
        return this.request('/grammar/usage', {
            method: 'GET'
        });
    }

    // Admin methods
    async getUsers() {
        return this.request('/auth/users', {
            method: 'GET'
        });
    }

    async updateUser(userId, userData) {
        return this.request(`/auth/users/${userId}`, {
            method: 'PUT',
            body: JSON.stringify(userData)
        });
    }

    async deleteUser(userId) {
        return this.request(`/auth/users/${userId}`, {
            method: 'DELETE'
        });
    }
}

// Authentication helper functions
class AuthHelper {
    constructor() {
        this.api = new ApiClient();
    }

    // Check if user is logged in
    isLoggedIn() {
        const token = this.api.getToken();
        const userData = localStorage.getItem('userData');
        return !!(token && userData);
    }

    // Get current user data
    getCurrentUser() {
        const userData = localStorage.getItem('userData');
        return userData ? JSON.parse(userData) : null;
    }

    // Save user data
    saveUserData(userData) {
        localStorage.setItem('userData', JSON.stringify(userData));
    }

    // Clear user data
    clearUserData() {
        localStorage.removeItem('userData');
        localStorage.removeItem('authToken');
    }

    // Show/hide elements based on login status
    updateUIForAuthState() {
        const isLoggedIn = this.isLoggedIn();
        const userData = this.getCurrentUser();

        // Update login/logout buttons
        const loginBtn = document.querySelector('.login-btn');
        const logoutBtn = document.querySelector('.logout-btn');
        const userInfo = document.querySelector('.user-info');

        if (loginBtn) {
            loginBtn.style.display = isLoggedIn ? 'none' : 'block';
        }

        if (logoutBtn) {
            logoutBtn.style.display = isLoggedIn ? 'block' : 'none';
        }

        if (userInfo && isLoggedIn && userData) {
            userInfo.textContent = `Welcome, ${userData.username}`;
            userInfo.style.display = 'block';
        } else if (userInfo) {
            userInfo.style.display = 'none';
        }
    }

    // Handle login form
    async handleLogin(formData) {
        try {
            const response = await this.api.login(formData);
            
            if (response.success) {
                this.saveUserData(response.data);
                this.updateUIForAuthState();
                return response;
            } else {
                throw new Error(response.error || 'Login failed');
            }
        } catch (error) {
            console.error('Login error:', error);
            throw error;
        }
    }

    // Handle registration form
    async handleRegister(formData) {
        try {
            const response = await this.api.register(formData);
            
            if (response.success) {
                this.saveUserData(response.data);
                this.updateUIForAuthState();
                return response;
            } else {
                throw new Error(response.error || 'Registration failed');
            }
        } catch (error) {
            console.error('Registration error:', error);
            throw error;
        }
    }

    // Handle logout
    async handleLogout() {
        try {
            await this.api.logout();
            this.clearUserData();
            this.updateUIForAuthState();
            
            // Redirect to home page
            window.location.href = '/';
        } catch (error) {
            console.error('Logout error:', error);
        }
    }

    // Verify token on page load
    async verifyAuth() {
        if (!this.isLoggedIn()) {
            return false;
        }

        try {
            const response = await this.api.verifyToken();
            
            if (response.success) {
                this.saveUserData(response.data);
                this.updateUIForAuthState();
                return true;
            } else {
                this.clearUserData();
                this.updateUIForAuthState();
                return false;
            }
        } catch (error) {
            console.error('Auth verification error:', error);
            this.clearUserData();
            this.updateUIForAuthState();
            return false;
        }
    }
}

// Initialize global instances
const apiClient = new ApiClient();
const authHelper = new AuthHelper();

// Utility functions
function showMessage(message, type = 'info') {
    // Remove existing messages
    const existingMessages = document.querySelectorAll('.message');
    existingMessages.forEach(msg => msg.remove());

    // Create message element
    const messageDiv = document.createElement('div');
    messageDiv.className = `message message-${type}`;
    messageDiv.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        border-radius: 5px;
        color: white;
        font-weight: bold;
        z-index: 10000;
        max-width: 400px;
        word-wrap: break-word;
    `;

    // Set colors based on type
    switch (type) {
        case 'success':
            messageDiv.style.backgroundColor = '#4CAF50';
            break;
        case 'error':
            messageDiv.style.backgroundColor = '#f44336';
            break;
        case 'warning':
            messageDiv.style.backgroundColor = '#ff9800';
            break;
        default:
            messageDiv.style.backgroundColor = '#2196F3';
    }

    messageDiv.textContent = message;
    document.body.appendChild(messageDiv);

    // Auto remove after 5 seconds
    setTimeout(() => {
        if (messageDiv.parentNode) {
            messageDiv.parentNode.removeChild(messageDiv);
        }
    }, 5000);
}

function showLoading(show = true) {
    let loader = document.querySelector('.loading-overlay');
    
    if (show) {
        if (!loader) {
            loader = document.createElement('div');
            loader.className = 'loading-overlay';
            loader.innerHTML = `
                <div class="loading-spinner">
                    <div class="spinner"></div>
                    <p>Loading...</p>
                </div>
            `;
            loader.style.cssText = `
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.5);
                display: flex;
                justify-content: center;
                align-items: center;
                z-index: 9999;
            `;
            
            const spinner = loader.querySelector('.loading-spinner');
            spinner.style.cssText = `
                text-align: center;
                color: white;
            `;
            
            const spinnerDiv = loader.querySelector('.spinner');
            spinnerDiv.style.cssText = `
                border: 4px solid #f3f3f3;
                border-top: 4px solid #3498db;
                border-radius: 50%;
                width: 40px;
                height: 40px;
                animation: spin 2s linear infinite;
                margin: 0 auto 20px;
            `;
            
            // Add spinner animation
            if (!document.querySelector('#spinner-style')) {
                const style = document.createElement('style');
                style.id = 'spinner-style';
                style.textContent = `
                    @keyframes spin {
                        0% { transform: rotate(0deg); }
                        100% { transform: rotate(360deg); }
                    }
                `;
                document.head.appendChild(style);
            }
            
            document.body.appendChild(loader);
        }
        loader.style.display = 'flex';
    } else {
        if (loader) {
            loader.style.display = 'none';
        }
    }
}

// Initialize auth state on page load
document.addEventListener('DOMContentLoaded', () => {
    authHelper.verifyAuth();
});

// Export for use in other scripts
window.apiClient = apiClient;
window.authHelper = authHelper;
window.showMessage = showMessage;
window.showLoading = showLoading;